/************ CONSTANTS ***********/
export const CURRENCY = '$';
